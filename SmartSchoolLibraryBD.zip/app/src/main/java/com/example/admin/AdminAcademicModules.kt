package com.example.admin

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.components.BookCoverArt
import com.example.components.DestructiveConfirmDialog
import com.example.components.FormEditorDialog
import com.example.data.DirectUploadDraft
import com.example.data.DirectUploadState
import com.example.data.SelectedCoverInfo
import com.example.data.SelectedPdfInfo
import com.example.data.UploadCategory
import com.example.model.AcademicStream
import com.example.model.DefaultCatalogSeed
import com.example.model.GuideNote
import com.example.model.SchoolClass
import com.example.model.Subject
import com.example.model.Textbook
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.RoyalBlue
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.ui.draw.clip

// --- A. Class Management ---
@Composable
fun AdminClassesModule(
    classes: List<SchoolClass>,
    onSave: (SchoolClass) -> Unit
) {
    var editing by remember { mutableStateOf<SchoolClass?>(null) }
    var showDialog by remember { mutableStateOf(false) }
    val displayList = classes.ifEmpty { DefaultCatalogSeed.defaultClasses }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("শ্রেণি ব্যবস্থাপনা (Classes)", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Button(
                    onClick = {
                        editing = SchoolClass(classNumber = 11, nameBn = "একাদশ শ্রেণি", nameEn = "Class 11", sortOrder = 7)
                        showDialog = true
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue, contentColor = Color.White)
                ) {
                    Icon(Icons.Filled.Add, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("নতুন শ্রেণি")
                }
            }
        }
        itemsIndexed(displayList, key = { idx, it -> it.id.ifBlank { "c_${it.classNumber}_$idx" } }) { _, cls ->
            Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("${cls.displayNameBn} (${cls.displayNameEn})", fontWeight = FontWeight.Bold)
                        Text(
                            "ক্রম: ${cls.sortOrder} • বিভাগ: ${if (cls.hasStreams) "হ্যাঁ" else "না"}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = cls.isActive,
                        onCheckedChange = { onSave(cls.copy(nameBn = cls.displayNameBn, nameEn = cls.displayNameEn, isActive = it)) }
                    )
                    IconButton(onClick = { editing = cls; showDialog = true }) {
                        Icon(Icons.Filled.Edit, contentDescription = "Edit class")
                    }
                }
            }
        }
    }

    if (showDialog && editing != null) {
        var classNumber by remember(editing) { mutableStateOf(editing!!.classNumber.toString()) }
        var nameBn by remember(editing) { mutableStateOf(editing!!.displayNameBn) }
        var nameEn by remember(editing) { mutableStateOf(editing!!.displayNameEn) }
        var sortOrder by remember(editing) { mutableStateOf(editing!!.sortOrder.toString()) }
        var hasStreams by remember(editing) { mutableStateOf(editing!!.hasStreams) }

        FormEditorDialog(
            onDismissRequest = { showDialog = false },
            title = { Text("শ্রেণির তথ্য সংরক্ষণ", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) },
            content = {
                Column(modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(classNumber, { classNumber = it }, label = { Text("শ্রেণি নম্বর (১-১২)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(nameBn, { nameBn = it }, label = { Text("শ্রেণির বাংলা নাম *") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(nameEn, { nameEn = it }, label = { Text("English Name *") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(sortOrder, { sortOrder = it }, label = { Text("প্রদর্শন ক্রম (Sort Order)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.fillMaxWidth())
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Text("বিভাগ রয়েছে (Science/Humanities/Business)", modifier = Modifier.weight(1f))
                        Switch(checked = hasStreams, onCheckedChange = { hasStreams = it })
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    val num = classNumber.toIntOrNull()?.coerceIn(1, 12) ?: 5
                    val finalBn = nameBn.trim().ifBlank { editing!!.displayNameBn }
                    val finalEn = nameEn.trim().ifBlank { editing!!.displayNameEn }
                    onSave(
                        editing!!.copy(
                            id = editing!!.id.ifBlank { "class_$num" },
                            classNumber = num,
                            nameBn = finalBn,
                            nameEn = finalEn,
                            hasStreams = hasStreams,
                            sortOrder = sortOrder.toIntOrNull()?.coerceIn(0, 1000) ?: num
                        )
                    )
                    showDialog = false
                }) { Text("সংরক্ষণ করুন") }
            },
            dismissButton = { TextButton(onClick = { showDialog = false }) { Text("বাতিল") } }
        )
    }
}

// --- B. Stream Management ---
@Composable
fun AdminStreamsModule(
    streams: List<AcademicStream>,
    onSave: (AcademicStream) -> Unit
) {
    val display = streams.ifEmpty { DefaultCatalogSeed.defaultStreams }
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Text("বিভাগ ব্যবস্থাপনা (৯ম ও ১০ম শ্রেণি)", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
        itemsIndexed(display, key = { idx, it -> "${it.code}_$idx" }) { _, st ->
            Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("${st.displayNameBn} (${st.displayNameEn})", fontWeight = FontWeight.Bold)
                        Text("Code: ${st.code}", style = MaterialTheme.typography.bodySmall)
                    }
                    Switch(
                        checked = st.isActive,
                        onCheckedChange = { onSave(st.copy(nameBn = st.displayNameBn, nameEn = st.displayNameEn, isActive = it)) }
                    )
                }
            }
        }
    }
}

// --- C. Subject Management ---
@Composable
fun AdminSubjectsModule(
    subjects: List<Subject>,
    onSave: (Subject) -> Unit,
    onDelete: (String) -> Unit
) {
    var editing by remember { mutableStateOf<Subject?>(null) }
    var showDialog by remember { mutableStateOf(false) }
    var deleteTarget by remember { mutableStateOf<Subject?>(null) }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("বিষয় ব্যবস্থাপনা (Subjects)", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Button(onClick = { editing = Subject(); showDialog = true }) {
                    Icon(Icons.Filled.Add, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("নতুন বিষয়")
                }
            }
        }
        itemsIndexed(subjects, key = { idx, it -> it.id.ifBlank { "subj_$idx" } }) { _, subj ->
            Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("${subj.nameBn} (${subj.nameEn})", fontWeight = FontWeight.Bold)
                        Text("শ্রেণি ${subj.classNumber} • বিভাগ: ${subj.stream}", style = MaterialTheme.typography.bodySmall)
                    }
                    Switch(checked = subj.isActive, onCheckedChange = { onSave(subj.copy(isActive = it)) })
                    IconButton(onClick = { editing = subj; showDialog = true }) { Icon(Icons.Filled.Edit, contentDescription = "Edit") }
                    IconButton(onClick = { deleteTarget = subj }) { Icon(Icons.Filled.DeleteOutline, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error) }
                }
            }
        }
    }

    if (showDialog && editing != null) {
        var nameBn by remember(editing) { mutableStateOf(editing!!.nameBn) }
        var nameEn by remember(editing) { mutableStateOf(editing!!.nameEn) }
        var cls by remember(editing) { mutableIntStateOf(editing!!.classNumber) }
        var stream by remember(editing) { mutableStateOf(editing!!.stream) }

        FormEditorDialog(
            onDismissRequest = { showDialog = false },
            title = { Text("বিষয় সংরক্ষণ", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) },
            content = {
                Column(modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(nameBn, { nameBn = it }, label = { Text("বিষয়ের বাংলা নাম *") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(nameEn, { nameEn = it }, label = { Text("English Name *") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        (5..10).forEach { c ->
                            FilterChip(selected = cls == c, onClick = { cls = c }, label = { Text("Class $c") })
                        }
                    }
                    if (cls >= 9) {
                        Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("ALL", "SCIENCE", "HUMANITIES", "BUSINESS").forEach { st ->
                                FilterChip(selected = stream == st, onClick = { stream = st }, label = { Text(st) })
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (nameBn.isNotBlank()) {
                        onSave(
                            editing!!.copy(
                                nameBn = nameBn.trim(),
                                nameEn = nameEn.trim().ifBlank { nameBn.trim() },
                                classNumber = cls,
                                stream = if (cls >= 9) stream else "ALL"
                            )
                        )
                        showDialog = false
                    }
                }) { Text("সংরক্ষণ") }
            },
            dismissButton = { TextButton(onClick = { showDialog = false }) { Text("বাতিল") } }
        )
    }

    deleteTarget?.let { t ->
        DestructiveConfirmDialog(
            title = "বিষয় মুছে ফেলবেন?",
            message = "\"${t.nameBn}\" স্থায়ীভাবে মুছে ফেলা হবে।",
            onConfirm = { onDelete(t.id) },
            onDismiss = { deleteTarget = null }
        )
    }
}

// --- D. Original Textbooks Management (Direct File Upload — Zero URL Inputs) ---
@Composable
fun AdminBooksModule(
    books: List<Textbook>,
    subjects: List<Subject>,
    onSave: (Textbook) -> Unit,
    onDelete: (String) -> Unit,
    uploadState: DirectUploadState = DirectUploadState.Idle,
    onResetUploadState: () -> Unit = {},
    onDirectUpload: (DirectUploadDraft, SelectedCoverInfo?, SelectedPdfInfo?) -> Unit = { _, _, _ -> },
    onGoAdminHome: (() -> Unit)? = null
) {
    var editingBookId by rememberSaveable { mutableStateOf<String?>(null) }
    var showUploadScreen by rememberSaveable { mutableStateOf(false) }
    var deleteTarget by remember { mutableStateOf<Textbook?>(null) }
    val editing = remember(books, editingBookId) {
        editingBookId?.let { id -> books.firstOrNull { it.id == id } }
    }

    if (showUploadScreen) {
        AdminBookUploadScreen(
            initialCategory = UploadCategory.ORIGINAL_TEXTBOOKS,
            editingBook = editing,
            editingGuide = null,
            subjects = subjects,
            uploadState = uploadState,
            onResetUploadState = onResetUploadState,
            onSubmitUpload = onDirectUpload,
            onBack = {
                onResetUploadState()
                showUploadScreen = false
                editingBookId = null
            },
            onGoAdminHome = {
                onResetUploadState()
                showUploadScreen = false
                editingBookId = null
                onGoAdminHome?.invoke()
            }
        )
        return
    }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("মূল পাঠ্যবই ব্যবস্থাপনা (${books.size})", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Button(
                    onClick = {
                        editingBookId = null
                        onResetUploadState()
                        showUploadScreen = true
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldDark, contentColor = Color.White)
                ) {
                    Icon(Icons.Filled.Add, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("নতুন বই যোগ করুন")
                }
            }
        }
        itemsIndexed(books, key = { idx, it -> it.id.ifBlank { "book_$idx" } }) { _, book ->
            Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .width(46.dp)
                            .aspectRatio(0.72f)
                            .clip(RoundedCornerShape(8.dp))
                    ) {
                        BookCoverArt(
                            itemId = book.id.ifBlank { "adm_b" },
                            rawCoverUrl = book.effectiveCoverRef,
                            title = book.titleBn,
                            subject = book.subjectNameBn,
                            badgeLabel = book.edition,
                            classNumber = book.classNumber,
                            isGuide = false,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(book.titleBn, fontWeight = FontWeight.Bold)
                        Text(
                            "শ্রেণি ${book.classNumber} (${book.stream}) • ${book.subjectNameBn} • ${if (book.isPremium) "প্রিমিয়াম" else "ফ্রি"} • ${if (book.isPublished) "প্রকাশিত" else "অপ্রকাশিত"}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (book.pdfFileName.isNotBlank()) {
                            Text(
                                "PDF: ${book.pdfFileName}",
                                style = MaterialTheme.typography.labelSmall,
                                color = EmeraldDark
                            )
                        }
                    }
                    IconButton(onClick = {
                        editingBookId = book.id
                        onResetUploadState()
                        showUploadScreen = true
                    }) { Icon(Icons.Filled.Edit, contentDescription = "Edit") }
                    IconButton(onClick = { deleteTarget = book }) { Icon(Icons.Filled.DeleteOutline, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error) }
                }
            }
        }
    }

    deleteTarget?.let { t ->
        DestructiveConfirmDialog(
            title = "পাঠ্যবই মুছে ফেলবেন?",
            message = "\"${t.titleBn}\" পাঠ্যবইটি ডাটাবেজ থেকে স্থায়ীভাবে মুছে যাবে।",
            onConfirm = { onDelete(t.id) },
            onDismiss = { deleteTarget = null }
        )
    }
}

// --- E. Guides & Notes Management (Direct File Upload — Zero URL Inputs) ---
@Composable
fun AdminGuidesModule(
    guides: List<GuideNote>,
    subjects: List<Subject>,
    onSave: (GuideNote) -> Unit,
    onDelete: (String) -> Unit,
    uploadState: DirectUploadState = DirectUploadState.Idle,
    onResetUploadState: () -> Unit = {},
    onDirectUpload: (DirectUploadDraft, SelectedCoverInfo?, SelectedPdfInfo?) -> Unit = { _, _, _ -> },
    onGoAdminHome: (() -> Unit)? = null
) {
    var editingGuideId by rememberSaveable { mutableStateOf<String?>(null) }
    var showUploadScreen by rememberSaveable { mutableStateOf(false) }
    var deleteTarget by remember { mutableStateOf<GuideNote?>(null) }
    val editing = remember(guides, editingGuideId) {
        editingGuideId?.let { id -> guides.firstOrNull { it.id == id } }
    }

    if (showUploadScreen) {
        AdminBookUploadScreen(
            initialCategory = UploadCategory.GUIDES_AND_NOTES,
            editingBook = null,
            editingGuide = editing,
            subjects = subjects,
            uploadState = uploadState,
            onResetUploadState = onResetUploadState,
            onSubmitUpload = onDirectUpload,
            onBack = {
                onResetUploadState()
                showUploadScreen = false
                editingGuideId = null
            },
            onGoAdminHome = {
                onResetUploadState()
                showUploadScreen = false
                editingGuideId = null
                onGoAdminHome?.invoke()
            }
        )
        return
    }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("গাইড ও নোট ব্যবস্থাপনা (${guides.size})", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Button(
                    onClick = {
                        editingGuideId = null
                        onResetUploadState()
                        showUploadScreen = true
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldDark, contentColor = Color.White)
                ) {
                    Icon(Icons.Filled.Add, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("নতুন গাইড/নোট")
                }
            }
        }
        itemsIndexed(guides, key = { idx, it -> it.id.ifBlank { "guide_$idx" } }) { _, g ->
            Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .width(46.dp)
                            .aspectRatio(0.72f)
                            .clip(RoundedCornerShape(8.dp))
                    ) {
                        BookCoverArt(
                            itemId = g.id.ifBlank { "adm_g" },
                            rawCoverUrl = g.effectiveCoverRef,
                            title = g.titleBn,
                            subject = g.subjectNameBn,
                            badgeLabel = g.guideType,
                            classNumber = g.classNumber,
                            isGuide = true,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(g.titleBn, fontWeight = FontWeight.Bold)
                        Text("শ্রেণি ${g.classNumber} • ${g.subjectNameBn} • ${g.chapter} • ${g.guideType}", style = MaterialTheme.typography.bodySmall)
                        if (g.pdfFileName.isNotBlank()) {
                            Text(
                                "PDF: ${g.pdfFileName}",
                                style = MaterialTheme.typography.labelSmall,
                                color = EmeraldDark
                            )
                        }
                    }
                    IconButton(onClick = {
                        editingGuideId = g.id
                        onResetUploadState()
                        showUploadScreen = true
                    }) { Icon(Icons.Filled.Edit, contentDescription = "Edit") }
                    IconButton(onClick = { deleteTarget = g }) { Icon(Icons.Filled.DeleteOutline, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error) }
                }
            }
        }
    }

    deleteTarget?.let { t ->
        DestructiveConfirmDialog(
            title = "গাইড/নোট মুছে ফেলবেন?",
            message = "\"${t.titleBn}\" মুছে ফেলা হবে।",
            onConfirm = { onDelete(t.id) },
            onDismiss = { deleteTarget = null }
        )
    }
}
